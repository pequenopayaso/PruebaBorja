async function cargarEstadisticas() {
    
    const respuesta = await fetch("data/juegos.csv");

    const texto = await respuesta.text();

    const filas = texto.split("\n");

    let terminadosSI = 0;
    let terminadosNO = 0;

    const completados = {};

    const plataformas = {};

    const generos = {};

    const formatos = {};

    const origenes = {};

    for (let i = 1; i < filas.length; i++) {

        const fila = filas[i].trim();

        if(!fila) continue;

        const datos = fila.split(";");

        const terminado = datos[3];

        const completado = datos[4];

        const plataforma = datos[2];
        
        const genero = datos[6];

        const origen = datos[9];

        if (terminado === "SI") {

            terminadosSI++;

        }  else {

            terminadosNO++;

        }

        if (completados[completado]) {

            completados[completado]++;
        
        } else {

            completados[completado] = 1;
        }

        if (plataformas[plataforma]) {
            plataformas[plataforma]++;
        } else {
            plataformas[plataforma] = 1;
        }

        if (generos[genero]) {
            generos[genero]++;
        } else {
            generos[genero] = 1;
        }

        const formato = datos[7];

        if (formatos[formato]) {
            formatos[formato]++;
        } else {
            formatos[formato] = 1;
        }

        if(origenes[origen]) {
            origenes[origen]++;
        } else {
            origenes[origen] = 1;
        }
    
    }

    const contenedor =
        document.getElementById("stats-container");

        contenedor.innerHTML = `
        
            <div class="stats-table">

                <h2>🎮 Juegos Terminados</h2>

                <table>

                    <tr>
                        <th>Estado</th>
                        <th>Total</th>
                    </tr>

                    <tr>
                        <td>SI</td>
                        <td>${terminadosSI}</td>
                    </tr>

                     <tr>
                        <td>NO</td>
                        <td>${terminadosNO}</td>
                    </tr>

                </table>

            </div>

        
        `;

    let tablaCompletados = `
    
        <div class="stats-table">
        <h2>🏆 Completados</h2>

        <table>
            <tr>
                <th>Estado</th>
                <th>Total</th>
            </tr>

    `;

    for (const estado in completados) {

        tablaCompletados += `

            <tr>
                <td>${estado}</td>
                <td>${completados[estado]}</td>
            </tr>
        `
    }

    tablaCompletados += `
        </table>
        </div>
    `;

    contenedor.innerHTML += tablaCompletados;

    contenedor.innerHTML += crearTabla(
        "🎮 Plataformas",
        plataformas
    );

    contenedor.innerHTML += crearTabla(
        "🏷️ Géneros",
        generos
    );

    contenedor.innerHTML += crearTabla(
        "💿 Formatos",
        formatos
    );

    contenedor.innerHTML += crearTabla(
        "📦 Origen",
        origenes
    );
   
}


cargarEstadisticas();

function crearTabla(titulo, datos) {

    let tabla = `
    
        <div class="stats-table">

            <h2>${titulo}</h2>

            <table>

                <tr>
                    <th>Elemento</th>
                    <th>Total</th>
                </tr>

    `;

        const elementos = Object.entries(datos);

        elementos.sort((a, b) => b[1] - a[1]);

        for (const [clave, valor] of elementos) {

            tabla += `
                <tr>
                    <td>${clave}</td>
                    <td>${valor}</td>
                </tr>
            `;
        
        }

    tabla += `
            </table>
        </div>
    `;

    return tabla;
}